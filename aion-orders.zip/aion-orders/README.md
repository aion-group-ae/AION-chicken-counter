# AION Orders — Stage 1

Local ordering system: customer order page (Arabic/English, mobile-first), stock reservation, tracking page with
phone verification, staff dashboard with audit log and picking list. **Payment gateway, WhatsApp and Karson are NOT
implemented yet (Stages 3–5).** Only cash on delivery/pickup exists, controlled by the `cod_enabled` setting.

## Setup
    python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
    cp .env.example .env   # then: export $(grep -v '^#' .env | cut -d' ' -f1 | xargs)  (or set variables yourself)
    export FLASK_APP=aion.app:create_app
    flask create-staff admin --role admin          # prompts for a password (min 10 chars)
    flask seed-sample                              # LOCAL TESTING ONLY placeholder data
    flask run                                      # http://127.0.0.1:5000  — staff: /staff

## Real data (replace the sample)
    flask add-product "Eggs" "بيض" "Carton of 30" "كرتون ٣٠" <price_AED> <stock>
    flask set-stock <product_id> <on_hand>
    flask set-setting cod_enabled 1 | discount_percent 0 | delay_minutes 120 | max_qty_per_line 50 | support_phone +971...
Delivery areas, pickup points and time slots are rows in `delivery_areas`, `pickup_points`, `time_slots`
(admin screens come in Stage 6; until then edit via sqlite3). Prices/fees/stock are never hard-coded.

## Tests
    python3 -m unittest discover -s tests -t .

## Design notes
- SQLite via stdlib `sqlite3` + numbered SQL migrations in `aion/migrations/` (portable to PostgreSQL). SQLAlchemy was not
  used because it could not be installed in the build environment; the service layer isolates SQL if you migrate later.
- Money is integer fils. Stock: `stock_reserved` is incremented atomically at order creation (guarded UPDATE), released on cancel,
  and deducted from `stock_on_hand` at handover.
- Tracking: unguessable token link + last-4-digits phone check (or order number + full phone). Attempts are throttled
  per process (in-memory); use a shared store/reverse proxy limits if you run several workers.
- Timestamps are stored in UTC; the UI labels them UTC.

## Production checklist
Set `AION_TEST_MODE=0` and a strong `AION_SECRET_KEY`; serve behind HTTPS (cookies become Secure); run with
`gunicorn "aion.app:create_app()"`; back up the DB file; create real staff accounts; remove sample data.
