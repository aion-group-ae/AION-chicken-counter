"""All business rules. No Flask imports so it is testable on its own. Money is integer fils (100 fils = 1 AED)."""
import re, secrets
from datetime import datetime, timedelta, timezone, date
from .db import tx

UTC = timezone.utc
STATUSES = ["awaiting_confirmation", "confirmed", "awaiting_payment", "paid", "queued", "picking", "quality_check",
            "packing", "ready", "handed_over", "cancelled", "refund_pending", "refunded"]
TRANSITIONS = {  # configurable state machine
    "awaiting_confirmation": ["confirmed", "cancelled"],
    "confirmed": ["awaiting_payment", "paid", "cancelled"],
    "awaiting_payment": ["paid", "cancelled"],
    "paid": ["queued", "cancelled", "refund_pending"],
    "queued": ["picking", "cancelled"],
    "picking": ["quality_check", "cancelled"],
    "quality_check": ["packing", "picking", "cancelled"],
    "packing": ["ready", "cancelled"],
    "ready": ["handed_over", "cancelled"],
    "handed_over": [], "cancelled": [], "refund_pending": ["refunded"], "refunded": [],
}
PREP_STATUSES = ["paid", "queued", "picking", "quality_check", "packing"]

class OrderError(Exception):
    def __init__(self, code, detail=""):
        super().__init__(code); self.code, self.detail = code, detail
class TransitionError(Exception): pass

def now(): return datetime.now(UTC).replace(microsecond=0)
def iso(dt): return dt.isoformat(timespec="seconds")
def setting(conn, key, default=""):
    r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else default

_DIG = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
def normalize_phone(raw):
    """UAE mobile only (WhatsApp-capable). Returns +9715XXXXXXXX or None."""
    d = re.sub(r"[^\d+]", "", (raw or "").translate(_DIG))
    if d.startswith("+"): d = d[1:]
    elif d.startswith("00"): d = d[2:]
    elif d.startswith("0"): d = "971" + d[1:]
    elif len(d) == 9 and d.startswith("5"): d = "971" + d
    return "+" + d if re.fullmatch(r"9715\d{8}", d) else None

def _int(v):
    try: return int(v)
    except (TypeError, ValueError): return 0

def build_quote(conn, f, today=None):
    """Validate a customer request against live DB data and compute totals. Raises OrderError."""
    today = today or now().date()
    items = {_int(k): _int(v) for k, v in (f.get("items") or {}).items() if _int(v) > 0}
    if not items: raise OrderError("no_items")
    maxq = _int(setting(conn, "max_qty_per_line", "50"))
    lines, subtotal = [], 0
    for pid, qty in sorted(items.items()):
        p = conn.execute("SELECT * FROM products WHERE id=? AND active=1", (pid,)).fetchone()
        if not p: raise OrderError("product")
        if qty > maxq: raise OrderError("bad_qty", str(maxq))
        if p["stock_on_hand"] - p["stock_reserved"] < qty:
            raise OrderError("stock", f'{p["name_en"]} / {p["name_ar"]}')
        lines.append({"product": dict(p), "qty": qty, "unit": p["price_fils"], "line": qty * p["price_fils"]})
        subtotal += qty * p["price_fils"]
    name = (f.get("name") or "").strip()
    if len(name) < 2: raise OrderError("name")
    phone = normalize_phone(f.get("phone"))
    if not phone: raise OrderError("phone")
    try: d = date.fromisoformat(f.get("date") or "")
    except ValueError: raise OrderError("date")
    if d < today or d > today + timedelta(days=14): raise OrderError("date")
    slot = conn.execute("SELECT * FROM time_slots WHERE id=? AND active=1", (_int(f.get("slot_id")),)).fetchone()
    if not slot: raise OrderError("slot")
    method, fee, address = f.get("method"), 0, None
    if method == "delivery":
        a = conn.execute("SELECT * FROM delivery_areas WHERE id=? AND active=1", (_int(f.get("area_id")),)).fetchone()
        if not a: raise OrderError("area")
        address = (f.get("address") or "").strip()
        if len(address) < 5: raise OrderError("address")
        fee = 0 if (a["free_over_fils"] is not None and subtotal >= a["free_over_fils"]) else a["fee_fils"]
        place = a["name"]
    elif method == "pickup":
        pp = conn.execute("SELECT * FROM pickup_points WHERE id=? AND active=1", (_int(f.get("pickup_id")),)).fetchone()
        if not pp: raise OrderError("pickup")
        place = pp["name"]
    else:
        raise OrderError("method")
    if f.get("payment_method") != "cash" or setting(conn, "cod_enabled") != "1":
        raise OrderError("payment")  # only admin-enabled cash exists until a gateway is configured (Stage 3)
    discount = subtotal * _int(setting(conn, "discount_percent", "0")) // 100
    return {"lines": lines, "subtotal": subtotal, "fee": fee, "discount": discount, "total": subtotal + fee - discount,
            "name": name, "phone": phone, "method": method, "place": place, "address": address,
            "date": d.isoformat(), "slot": slot["label"], "payment_method": "cash"}

def _audit(conn, oid, actor, old, new, note=None):
    conn.execute("INSERT INTO audit_log(order_id,at,actor,old_status,new_status,note) VALUES(?,?,?,?,?,?)",
                 (oid, iso(now()), actor, old, new, note))

def create_order(conn, f, idem_key=None):
    """Validate, atomically reserve stock, persist. Duplicate idem_key returns the existing order."""
    if idem_key:
        ex = conn.execute("SELECT * FROM orders WHERE idem_key=?", (idem_key,)).fetchone()
        if ex: return ex
    q = build_quote(conn, f)
    t = iso(now()); token = secrets.token_urlsafe(18)
    with tx(conn):
        if idem_key:
            ex = conn.execute("SELECT * FROM orders WHERE idem_key=?", (idem_key,)).fetchone()
            if ex: return ex
        for ln in q["lines"]:  # guarded update: can never oversell
            cur = conn.execute("UPDATE products SET stock_reserved=stock_reserved+? WHERE id=? AND stock_on_hand-stock_reserved>=?",
                               (ln["qty"], ln["product"]["id"], ln["qty"]))
            if cur.rowcount != 1: raise OrderError("stock", ln["product"]["name_en"])
        oid = conn.execute(
            """INSERT INTO orders(order_no,token,idem_key,customer_name,phone,method,place_label,address,fulfil_date,slot_label,
               subtotal_fils,delivery_fee_fils,discount_fils,total_fils,status,payment_method,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            ("TMP-" + token, token, idem_key, q["name"], q["phone"], q["method"], q["place"], q["address"], q["date"], q["slot"],
             q["subtotal"], q["fee"], q["discount"], q["total"], "confirmed", q["payment_method"], t, t)).lastrowid
        conn.execute("UPDATE orders SET order_no=? WHERE id=?", (f"AION-{now():%y%m%d}-{oid:05d}", oid))
        for ln in q["lines"]:
            conn.execute("INSERT INTO order_items(order_id,product_id,qty,unit_price_fils) VALUES(?,?,?,?)",
                         (oid, ln["product"]["id"], ln["qty"], ln["unit"]))
        _audit(conn, oid, "customer", None, "confirmed")
        # Cash on delivery/pickup: payment *method* confirmed; money is collected at handover.
        conn.execute("UPDATE orders SET status='paid' WHERE id=?", (oid,))
        _audit(conn, oid, "system", "confirmed", "paid", "cash on delivery/pickup selected")
    return conn.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()

def set_status(conn, order_id, new, actor, note=None):
    with tx(conn):
        o = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        if not o: raise TransitionError("not found")
        old = o["status"]
        if new not in TRANSITIONS.get(old, []): raise TransitionError(f"{old} -> {new} is not allowed")
        items = conn.execute("SELECT product_id,qty FROM order_items WHERE order_id=?", (order_id,)).fetchall()
        pay = o["payment_status"]
        if new == "cancelled":
            for i in items:
                conn.execute("UPDATE products SET stock_reserved=stock_reserved-? WHERE id=?", (i["qty"], i["product_id"]))
            pay = "cancelled" if pay == "pending" else pay
        elif new == "handed_over":
            for i in items:
                conn.execute("UPDATE products SET stock_on_hand=stock_on_hand-?, stock_reserved=stock_reserved-? WHERE id=?",
                             (i["qty"], i["qty"], i["product_id"]))
            if o["payment_method"] == "cash": pay = "paid"  # staff action = cash received
        elif new == "refunded": pay = "refunded"
        conn.execute("UPDATE orders SET status=?, payment_status=?, updated_at=? WHERE id=?", (new, pay, iso(now()), order_id))
        _audit(conn, order_id, actor, old, new, note)

def assign(conn, order_id, staff_name, actor):
    with tx(conn):
        conn.execute("UPDATE orders SET assigned_to=? WHERE id=?", (staff_name or None, order_id))
        o = conn.execute("SELECT status FROM orders WHERE id=?", (order_id,)).fetchone()
        _audit(conn, order_id, actor, o["status"], o["status"], f"assigned to {staff_name or 'nobody'}")

DASH = {
    "new": "status IN ('awaiting_confirmation','confirmed')", "awaiting_payment": "status='awaiting_payment'",
    "paid": "status='paid'", "queued": "status='queued'", "picking": "status='picking'",
    "quality_check": "status='quality_check'", "packing": "status='packing'",
    "ready_pickup": "status='ready' AND method='pickup'", "out_for_delivery": "status='ready' AND method='delivery'",
    "handed_over": "status='handed_over'", "cancelled": "status='cancelled'",
}
def dashboard(conn, queue):
    cutoff = iso(now() - timedelta(minutes=_int(setting(conn, "delay_minutes", "120"))))
    qs = {k: (w, ()) for k, w in DASH.items()}
    qs["delayed"] = ("status NOT IN ('handed_over','cancelled','refunded') AND updated_at < ?", (cutoff,))
    counts = {k: conn.execute(f"SELECT COUNT(*) FROM orders WHERE {w}", a).fetchone()[0] for k, (w, a) in qs.items()}
    w, a = qs.get(queue, qs["paid"])
    out = []
    for o in conn.execute(f"SELECT * FROM orders WHERE {w} ORDER BY created_at LIMIT 200", a).fetchall():
        out.append({"o": o, "items": order_items(conn, o["id"]), "next": TRANSITIONS[o["status"]]})
    return counts, out

def picking_list(conn):
    ph = ",".join("?" * len(PREP_STATUSES))
    totals = conn.execute(f"""SELECT p.name_en,p.name_ar,p.pkg_en,p.pkg_ar,SUM(oi.qty) need,p.stock_on_hand
        FROM order_items oi JOIN orders o ON o.id=oi.order_id JOIN products p ON p.id=oi.product_id
        WHERE o.status IN ({ph}) GROUP BY p.id ORDER BY p.name_en""", PREP_STATUSES).fetchall()
    buckets = conn.execute(f"""SELECT o.fulfil_date,o.method,o.place_label,o.slot_label,p.name_en,p.name_ar,p.pkg_en,p.pkg_ar,
        SUM(oi.qty) qty,COUNT(DISTINCT o.id) orders FROM order_items oi JOIN orders o ON o.id=oi.order_id
        JOIN products p ON p.id=oi.product_id WHERE o.status IN ({ph})
        GROUP BY o.fulfil_date,o.method,o.place_label,o.slot_label,p.id
        ORDER BY o.fulfil_date,o.method,o.place_label,o.slot_label""", PREP_STATUSES).fetchall()
    return totals, buckets

def get_order_by_token(conn, token):
    return conn.execute("SELECT * FROM orders WHERE token=?", (token,)).fetchone()
def order_items(conn, oid):
    return conn.execute("""SELECT oi.qty,oi.unit_price_fils,p.name_en,p.name_ar,p.pkg_en,p.pkg_ar FROM order_items oi
        JOIN products p ON p.id=oi.product_id WHERE order_id=?""", (oid,)).fetchall()
def timeline(conn, o):
    done = {r["new_status"]: r["at"] for r in conn.execute("SELECT new_status,at FROM audit_log WHERE order_id=? ORDER BY id", (o["id"],))}
    path = ["confirmed", "paid", "queued", "picking", "quality_check", "packing", "ready", "handed_over"]
    if o["status"] == "cancelled": path = [s for s in path if s in done] + ["cancelled"]
    return [(s, done.get(s)) for s in path]
