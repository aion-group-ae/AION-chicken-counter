import os, re, tempfile, unittest
from datetime import timedelta
from werkzeug.security import generate_password_hash
from aion import db, services as S
from aion.app import create_app

def seed(c):
    with db.tx(c):
        c.execute("INSERT INTO products(name_en,name_ar,pkg_en,pkg_ar,price_fils,stock_on_hand) VALUES('Eggs','بيض','30','٣٠',1500,10)")
        c.execute("INSERT INTO delivery_areas(name,fee_fils,free_over_fils) VALUES('A',1000,10000)")
        c.execute("INSERT INTO pickup_points(name,hours) VALUES('P','9-5')")
        c.execute("INSERT INTO time_slots(label) VALUES('AM')")
        c.execute("INSERT INTO staff(username,pw_hash) VALUES('sam',?)", (generate_password_hash("correct-horse-1"),))

def form(qty=2, **kw):
    f = {"items": {"1": qty}, "name": "Omar", "phone": "050 123 4567", "method": "delivery", "area_id": "1", "address": "Villa 5, Al Dhaid",
         "date": (S.now().date() + timedelta(days=1)).isoformat(), "slot_id": "1", "payment_method": "cash"}
    f.update(kw); return f

class Base(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory(); self.path = os.path.join(self.dir.name, "t.db")
        self.app = create_app({"DB_PATH": self.path, "TESTING": True}); self.c = db.connect(self.path); seed(self.c)
    def tearDown(self): self.c.close(); self.dir.cleanup()
    def stock(self): r = self.c.execute("SELECT stock_on_hand h,stock_reserved r FROM products").fetchone(); return r["h"], r["r"]

class TestOrders(Base):
    def test_phone_normalisation(self):
        for raw in ("0501234567", "+971 50 123 4567", "00971501234567", "٠٥٠١٢٣٤٥٦٧", "501234567"):
            self.assertEqual(S.normalize_phone(raw), "+971501234567")
        self.assertIsNone(S.normalize_phone("041234567")); self.assertIsNone(S.normalize_phone("123"))
    def test_totals_and_delivery_fee(self):
        q = S.build_quote(self.c, form(2)); self.assertEqual((q["subtotal"], q["fee"], q["total"]), (3000, 1000, 4000))
        q = S.build_quote(self.c, form(7)); self.assertEqual((q["subtotal"], q["fee"]), (10500, 0))  # free-delivery threshold
        self.assertEqual(S.build_quote(self.c, form(2, method="pickup", pickup_id="1"))["fee"], 0)
    def test_discount_setting(self):
        with db.tx(self.c): self.c.execute("UPDATE settings SET value='10' WHERE key='discount_percent'")
        self.assertEqual(S.build_quote(self.c, form(2))["discount"], 300)
    def test_validation(self):
        for bad, code in ((form(0), "no_items"), (form(name="x"), "name"), (form(phone="12"), "phone"), (form(address=""), "address"),
                          (form(area_id="9"), "area"), (form(slot_id="9"), "slot"), (form(method="x"), "method"),
                          (form(date="2000-01-01"), "date"), (form(payment_method="card"), "payment")):
            with self.assertRaises(S.OrderError) as cm: S.create_order(self.c, bad)
            self.assertEqual(cm.exception.code, code)
        self.assertEqual(self.stock(), (10, 0))  # nothing reserved by failed attempts
    def test_cash_disabled_blocks_order(self):
        with db.tx(self.c): self.c.execute("UPDATE settings SET value='0' WHERE key='cod_enabled'")
        with self.assertRaises(S.OrderError): S.create_order(self.c, form())
    def test_stock_never_oversold(self):
        S.create_order(self.c, form(6)); self.assertEqual(self.stock(), (10, 6))
        with self.assertRaises(S.OrderError) as cm: S.create_order(self.c, form(5))
        self.assertEqual(cm.exception.code, "stock"); S.create_order(self.c, form(4)); self.assertEqual(self.stock(), (10, 10))
        with self.assertRaises(S.OrderError): S.create_order(self.c, form(1))
    def test_idempotent_confirm(self):
        a = S.create_order(self.c, form(2), "k1"); b = S.create_order(self.c, form(2), "k1")
        self.assertEqual(a["id"], b["id"]); self.assertEqual(self.c.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 1); self.assertEqual(self.stock(), (10, 2))
    def test_order_numbers_and_tokens_unique(self):
        a = S.create_order(self.c, form(1)); b = S.create_order(self.c, form(1))
        self.assertNotEqual(a["order_no"], b["order_no"]); self.assertNotEqual(a["token"], b["token"]); self.assertGreaterEqual(len(a["token"]), 20)
        self.assertRegex(a["order_no"], r"^AION-\d{6}-\d{5}$")

class TestStatus(Base):
    def walk(self, o, path):
        for s in path: S.set_status(self.c, o["id"], s, "sam")
    def test_full_flow_deducts_stock_and_marks_cash_paid(self):
        o = S.create_order(self.c, form(3)); self.assertEqual(o["status"], "paid"); self.assertEqual(o["payment_status"], "pending")
        self.walk(o, ["queued", "picking", "quality_check", "packing", "ready", "handed_over"])
        r = self.c.execute("SELECT * FROM orders WHERE id=?", (o["id"],)).fetchone()
        self.assertEqual((r["status"], r["payment_status"]), ("handed_over", "paid")); self.assertEqual(self.stock(), (7, 0))
    def test_invalid_transitions_rejected(self):
        o = S.create_order(self.c, form(1))
        for bad in ("handed_over", "packing", "ready", "refunded", "nonsense"):
            with self.assertRaises(S.TransitionError): S.set_status(self.c, o["id"], bad, "sam")
        self.walk(o, ["queued", "picking", "quality_check", "packing", "ready", "handed_over"])
        with self.assertRaises(S.TransitionError): S.set_status(self.c, o["id"], "cancelled", "sam")
    def test_cancel_releases_stock(self):
        o = S.create_order(self.c, form(4)); self.assertEqual(self.stock(), (10, 4)); S.set_status(self.c, o["id"], "cancelled", "sam")
        self.assertEqual(self.stock(), (10, 0))
        with self.assertRaises(S.TransitionError): S.set_status(self.c, o["id"], "queued", "sam")
    def test_audit_log(self):
        o = S.create_order(self.c, form(1)); S.set_status(self.c, o["id"], "queued", "sam")
        rows = self.c.execute("SELECT actor,old_status,new_status FROM audit_log WHERE order_id=? ORDER BY id", (o["id"],)).fetchall()
        self.assertEqual([tuple(r) for r in rows], [("customer", None, "confirmed"), ("system", "confirmed", "paid"), ("sam", "paid", "queued")])
    def test_picking_list_aggregates_and_flags_shortage(self):
        for n in (2, 4, 3): S.create_order(self.c, form(n, method="pickup", pickup_id="1"))
        t, b = S.picking_list(self.c); self.assertEqual(t[0]["need"], 9); self.assertEqual(len(b), 1); self.assertEqual(b[0]["qty"], 9)
        with db.tx(self.c): self.c.execute("UPDATE products SET stock_reserved=0, stock_on_hand=5")  # simulate a stock correction
        self.assertGreater(S.picking_list(self.c)[0][0]["need"], 5)
    def test_dashboard_delayed(self):
        o = S.create_order(self.c, form(1))
        with db.tx(self.c): self.c.execute("UPDATE orders SET updated_at='2000-01-01T00:00:00+00:00' WHERE id=?", (o["id"],))
        self.assertEqual(S.dashboard(self.c, "delayed")[0]["delayed"], 1)

class TestPersistence(Base):
    def test_survives_restart(self):
        o = S.create_order(self.c, form(2)); self.c.close()
        app2 = create_app({"DB_PATH": self.path}); c2 = db.connect(self.path)
        r = c2.execute("SELECT * FROM orders WHERE token=?", (o["token"],)).fetchone()
        self.assertEqual(r["total_fils"], 4000); self.assertEqual(c2.execute("SELECT stock_reserved FROM products").fetchone()[0], 2)
        self.assertEqual(c2.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0], 2); c2.close(); self.c = db.connect(self.path)

class TestHTTP(Base):
    def csrf(self, cl, path="/"):
        html = cl.get(path).get_data(as_text=True); return re.search(r'name="csrf" value="([^"]+)"', html).group(1)
    def post(self, cl, path, data, tokpath="/"):
        return cl.post(path, data={**data, "csrf": self.csrf(cl, tokpath)})
    def place(self, cl):
        f = {"qty_1": "2", "name": "Omar", "phone": "0501234567", "method": "delivery", "area_id": "1", "address": "Villa 5 Al Dhaid",
             "date": (S.now().date() + timedelta(days=1)).isoformat(), "slot_id": "1", "payment_method": "cash", "nonce": "n1"}
        self.assertEqual(self.post(cl, "/order/review", f, "/order").status_code, 200)
        return self.post(cl, "/order/confirm", f, "/order")
    def test_customer_flow_and_tracking_privacy(self):
        cl = self.app.test_client(); r = self.place(cl); self.assertEqual(r.status_code, 302)
        page = cl.get(r.headers["Location"]).get_data(as_text=True); self.assertIn("AION-", page); self.assertIn("40.00", page)
        token = r.headers["Location"].split("/t/")[1].split("?")[0]
        other = self.app.test_client()  # different browser: must verify first
        v = other.get(f"/t/{token}").get_data(as_text=True); self.assertNotIn("Omar", v); self.assertNotIn("AION-", v)
        bad = self.post(other, f"/t/{token}", {"last4": "0000"}, f"/t/{token}"); self.assertNotIn("AION-2", bad.get_data(as_text=True))
        ok = self.post(other, f"/t/{token}", {"last4": "4567"}, f"/t/{token}"); self.assertEqual(ok.status_code, 302)
        self.assertIn("AION-", other.get(f"/t/{token}").get_data(as_text=True))
        self.assertEqual(other.get("/t/does-not-exist").status_code, 404)
    def test_sequential_order_number_does_not_leak(self):
        self.place(self.app.test_client()); o = self.c.execute("SELECT order_no FROM orders").fetchone()[0]
        cl = self.app.test_client(); r = self.post(cl, "/track", {"order_no": o, "phone": "0509999999"}, "/track")
        self.assertEqual(r.status_code, 404); self.assertNotIn("Omar", r.get_data(as_text=True))
        self.assertEqual(self.post(cl, "/track", {"order_no": o, "phone": "0501234567"}, "/track").status_code, 302)
    def test_double_submit_creates_one_order(self):
        cl = self.app.test_client(); self.place(cl); self.place(cl)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 1)
    def test_csrf_enforced(self):
        self.assertEqual(self.app.test_client().post("/order/confirm", data={"name": "x"}).status_code, 400)
    def test_staff_requires_login_and_buttons_work(self):
        cl = self.app.test_client(); self.assertEqual(cl.get("/staff").status_code, 302); self.assertEqual(cl.get("/staff/picking").status_code, 302)
        self.assertEqual(self.post(cl, "/staff/login", {"username": "sam", "password": "nope"}, "/staff/login").status_code, 401)
        self.assertEqual(self.post(cl, "/staff/login", {"username": "sam", "password": "correct-horse-1"}, "/staff/login").status_code, 302)
        self.place(self.app.test_client()); self.assertIn("AION-", cl.get("/staff?q=paid").get_data(as_text=True))
        self.post(cl, "/staff/orders/1/status", {"new_status": "queued"}, "/staff"); self.assertEqual(self.c.execute("SELECT status FROM orders").fetchone()[0], "queued")
        self.post(cl, "/staff/orders/1/status", {"new_status": "handed_over"}, "/staff"); self.assertEqual(self.c.execute("SELECT status FROM orders").fetchone()[0], "queued")
        self.assertEqual(cl.get("/staff/picking").status_code, 200)
    def test_arabic_pages_render_rtl(self):
        h = self.app.test_client().get("/order?lang=ar").get_data(as_text=True); self.assertIn('dir="rtl"', h); self.assertIn("طلب جديد", h)

if __name__ == "__main__": unittest.main()
