# AION Orders (Stages 1–6)

Customer ordering (Arabic/English, mobile-first), stock reservation, tracking with phone verification, staff dashboard,
picking list, audit log, payment adapter (Stripe Checkout), WhatsApp Cloud API webhook + notifications, report.
**Karson is not implemented** (provider unidentified, see `aion/karson.py`). **Nothing external has been tested live**
(no network in the build environment): see "Integration status".

## Setup
    python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
    export FLASK_APP=aion.app:create_app AION_DB_PATH=aion.db AION_TEST_MODE=1
    flask create-staff admin --role admin
    # business data (prices/fees are YOURS — nothing is hard-coded):
    flask add-product "Eggs" "بيض" "Pack of 15 eggs" "عبوة ١٥ بيضة" 30 <STOCK_PACKS>
    flask add-area "Abu Dhabi / أبوظبي" 5 --free-over-qty 7   # 5 AED fee; free from 7 packs (--free-over <AED> also available)
    flask add-slot "09:00-12:00"                    # repeat per time slot
    flask add-pickup "<name>" "<opening hours>"     # optional pickup points
    flask set-stock <product_id> <on_hand> ; flask set-setting <key> <value>
    flask run                                       # customers: /   staff: /staff
Settings keys: cod_enabled, online_enabled, discount_percent, delay_minutes, max_qty_per_line, support_phone,
wa_template_<kind> (approved WhatsApp template names, e.g. wa_template_order_ready), wa_template_lang.

**No shell on your host?** Set `AION_ADMIN_USER` / `AION_ADMIN_PASSWORD`, restart once, sign in at `/staff/login`, then open
**Setup** (`/staff/admin`) to add the product, delivery area, time slots, pickup points and settings from the browser.
Until a product, a time slot and an area/pickup point exist, the order page shows "Ordering is not available yet".

## Tests
    python3 -m unittest discover -s tests -t .

## Integration status
| Part | Code | Tested here | Needs from you |
|---|---|---|---|
| Stripe Checkout + webhook | yes | signature, replay, amount check, state changes (unit tests, mocked provider) | Stripe account approved for UAE, `sk_test_` key, webhook secret, HTTPS URL |
| WhatsApp Cloud API | yes | webhook signature/handshake, dedupe, bot, outbox retry (mocked HTTP) | Meta business verification, number registration, access token, app secret, approved templates |
| Karson | stub only | — | exact provider name, official API docs link, desired function, sandbox credentials |

## Going live
1. HTTPS domain; set `AION_TEST_MODE=0`, strong `AION_SECRET_KEY`, `APP_BASE_URL`, all provider variables.
2. Stripe: test-mode end-to-end payment first (card 4242…), confirm the order flips to *paid* only after the webhook.
3. Meta: register webhook `/webhooks/whatsapp`, subscribe to `messages`; send a real test message to your own number.
4. Business-initiated notifications outside WhatsApp's 24-hour window need approved templates (`wa_template_*` settings).
5. Run `flask send-outbox` every minute (cron/systemd timer); run app with `gunicorn "aion.app:create_app()"` behind nginx.
6. Back up the SQLite file daily. Throttling is per-process: use one worker or add proxy-level rate limits.
Moving to PostgreSQL later: schema is plain SQL in `aion/migrations/`; the SQL is confined to `db.py` and `services.py`.

## Not done yet
Damaged/rejected/missing-item records and handed-over reconciliation, staff admin screens (catalogue is CLI/sqlite),
LLM layer (the deterministic menu bot is the baseline), ordering fully inside WhatsApp chat (bot sends the web link),
automated provider refunds (refund states exist; refund the money in the provider dashboard).
