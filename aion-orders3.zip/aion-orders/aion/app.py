import os, secrets, time, sqlite3
from datetime import timedelta
import click
from flask import Flask, g, request, session, redirect, url_for, render_template, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from . import db, services as S, payments, whatsapp, outbox, bot
from .i18n import T

_attempts = {}  # per-process throttle only; orders/settings/stock never live in memory
def throttled(key, limit=8, window=900):
    t = time.time(); L = [x for x in _attempts.get(key, []) if t - x < window]
    _attempts[key] = L + [t]
    return len(L) >= limit

def create_app(config=None):
    app = Flask(__name__)
    app.config.update(DB_PATH=os.environ.get("AION_DB_PATH", "aion.db"), SECRET_KEY=os.environ.get("AION_SECRET_KEY"),
                      TEST_MODE=os.environ.get("AION_TEST_MODE", "1") == "1", MAX_CONTENT_LENGTH=256 * 1024)
    app.config.update(config or {})
    if not app.config["SECRET_KEY"]:
        if not app.config["TEST_MODE"]: raise RuntimeError("AION_SECRET_KEY is required when AION_TEST_MODE=0")
        app.config["SECRET_KEY"] = secrets.token_hex(16)
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=not app.config["TEST_MODE"],
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=12))
    c = db.connect(app.config["DB_PATH"]); db.migrate(c)
    u, pw = os.environ.get("AION_ADMIN_USER", "").strip(), os.environ.get("AION_ADMIN_PASSWORD", "")
    if u and len(pw) >= 10 and not c.execute("SELECT 1 FROM staff").fetchone():  # first run only
        with db.tx(c): c.execute("INSERT INTO staff(username,pw_hash,role) VALUES(?,?,'admin')", (u, generate_password_hash(pw)))
    c.close()

    def conn():
        if "db" not in g: g.db = db.connect(app.config["DB_PATH"])
        return g.db
    @app.teardown_appcontext
    def _close(_):
        d = g.pop("db", None)
        if d: d.close()

    @app.before_request
    def _csrf():
        session.setdefault("csrf", secrets.token_urlsafe(16))
        if request.method == "POST" and not request.path.startswith("/webhooks/") and not secrets.compare_digest(request.form.get("csrf", ""), session["csrf"]):
            abort(400, "csrf")
    @app.after_request
    def _hdr(r):
        r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
                          "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'",
                          "Cache-Control": "no-store" if request.path.startswith(("/t/", "/staff")) else "no-cache"})
        return r

    @app.context_processor
    def _ctx():
        lang = cur_lang()
        def t(k): return T[lang].get(k, k)
        def aed(f): return f"{f/100:,.2f}"
        def pname(p): return p[f"name_{lang}"] + " — " + p[f"pkg_{lang}"]
        return dict(t=t, lang=lang, dir="rtl" if lang == "ar" else "ltr", aed=aed, pname=pname, csrf=session["csrf"],
                    test_mode=app.config["TEST_MODE"], staff=session.get("staff"), is_admin=session.get("role") == "admin", plabel=lambda o: t("ready_" + o["method"]) if o["status"] == "ready" else t("st_" + o["status"]))
    @app.after_request
    def _lang(r):
        if request.args.get("lang") in T: r.set_cookie("lang", request.args["lang"], max_age=31536000, samesite="Lax")
        return r

    def cur_lang():
        l = request.args.get("lang") or request.cookies.get("lang") or "en"
        return l if l in T else "en"
    def err_text(e):
        return T[cur_lang()].get("err_" + e.code, e.code) + (f" {e.detail}" if e.detail else "")
    def catalog():
        c = conn()
        d = dict(products=c.execute("SELECT *, stock_on_hand-stock_reserved AS avail FROM products WHERE active=1 ORDER BY id").fetchall(),
                    areas=c.execute("SELECT * FROM delivery_areas WHERE active=1").fetchall(),
                    points=c.execute("SELECT * FROM pickup_points WHERE active=1").fetchall(),
                    slots=c.execute("SELECT * FROM time_slots WHERE active=1").fetchall(),
                    ready=None, cod=S.setting(c, "cod_enabled") == "1", online=payments.configured() and S.setting(c, "online_enabled", "1") == "1", today=S.now().date().isoformat())
        d["ready"] = bool(d["products"] and d["slots"] and (d["areas"] or d["points"]))
        return d
    def form_data():
        f = request.form
        return {"items": {k[4:]: v for k, v in f.items() if k.startswith("qty_")}, **{k: f.get(k, "") for k in
                ("name", "phone", "method", "area_id", "address", "pickup_id", "date", "slot_id", "payment_method")}}

    @app.get("/")
    def home(): return render_template("home.html")
    @app.get("/products")
    def products(): return render_template("products.html", **catalog())
    @app.get("/support")
    def support(): return render_template("support.html", phone=S.setting(conn(), "support_phone"))

    @app.route("/order", methods=["GET", "POST"])
    def order():
        form = form_data() if request.method == "POST" else {}
        return render_template("order.html", form=form, nonce=secrets.token_urlsafe(12), **catalog())
    @app.post("/order/review")
    def review():
        f = form_data()
        try: q = S.build_quote(conn(), f)
        except S.OrderError as e:
            flash(err_text(e)); return render_template("order.html", form=f, nonce=request.form.get("nonce", ""), **catalog()), 422
        return render_template("review.html", q=q, form=f, nonce=request.form.get("nonce", ""))
    @app.post("/order/confirm")
    def confirm():
        f = form_data()
        try: o = S.create_order(conn(), f, idem_key=request.form.get("nonce") or None)
        except S.OrderError as e:
            flash(err_text(e)); return render_template("order.html", form=f, nonce=secrets.token_urlsafe(12), **catalog()), 422
        session.setdefault("verified", []).append(o["token"]); session.modified = True
        if o["payment_method"] == "online": return redirect(url_for("pay", token=o["token"]))
        return redirect(url_for("tracking", token=o["token"], new=1))

    @app.route("/track", methods=["GET", "POST"])
    def track():
        if request.method == "POST":
            if throttled("track:" + (request.remote_addr or "")): flash(err_text(S.OrderError("throttle"))); return render_template("track.html"), 429
            o = conn().execute("SELECT * FROM orders WHERE order_no=?", ((request.form.get("order_no") or "").strip().upper(),)).fetchone()
            if o and o["phone"] == S.normalize_phone(request.form.get("phone")):
                session.setdefault("verified", []).append(o["token"]); session.modified = True
                return redirect(url_for("tracking", token=o["token"]))
            flash(err_text(S.OrderError("verify"))); return render_template("track.html"), 404
        return render_template("track.html")
    @app.route("/t/<token>", methods=["GET", "POST"])
    def tracking(token):
        o = S.get_order_by_token(conn(), token)
        if not o: abort(404)
        if token not in session.get("verified", []):
            if request.method == "POST":
                if throttled("tok:" + token): flash(err_text(S.OrderError("throttle"))); return render_template("verify.html"), 429
                if secrets.compare_digest(request.form.get("last4", "").translate(S._DIG).strip(), o["phone"][-4:]):
                    session.setdefault("verified", []).append(token); session.modified = True
                    return redirect(url_for("tracking", token=token))
                flash(err_text(S.OrderError("verify")))
            return render_template("verify.html")
        return render_template("tracking.html", o=o, items=S.order_items(conn(), o["id"]), tl=S.timeline(conn(), o), new=request.args.get("new"), pay_available=payments.configured())

    # ---- staff ----
    def staff_only(fn):
        from functools import wraps
        @wraps(fn)
        def w(*a, **k):
            if not session.get("staff"): return redirect(url_for("login"))
            return fn(*a, **k)
        return w
    @app.route("/staff/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            u = (request.form.get("username") or "").strip()
            if throttled("login:" + (request.remote_addr or "") + u, 6): flash(err_text(S.OrderError("throttle"))); return render_template("login.html"), 429
            r = conn().execute("SELECT * FROM staff WHERE username=? AND active=1", (u,)).fetchone()
            if r and check_password_hash(r["pw_hash"], request.form.get("password", "")):
                session.clear(); session["staff"] = r["username"]; session["role"] = r["role"]; session["csrf"] = secrets.token_urlsafe(16); session.permanent = True
                return redirect(url_for("staff_home"))
            flash("Invalid credentials"); return render_template("login.html"), 401
        return render_template("login.html")
    def admin_only(fn):
        from functools import wraps
        @wraps(fn)
        def w(*a, **k):
            if not session.get("staff"): return redirect(url_for("login"))
            if session.get("role") != "admin": abort(403)
            return fn(*a, **k)
        return w
    @app.post("/staff/logout")
    def logout(): session.clear(); return redirect(url_for("login"))
    @app.get("/staff")
    @staff_only
    def staff_home():
        queue = request.args.get("q", "new")
        counts, rows = S.dashboard(conn(), queue)
        return render_template("dashboard.html", counts=counts, rows=rows, queue=queue,
                               members=[r[0] for r in conn().execute("SELECT username FROM staff WHERE active=1")])
    @app.post("/staff/orders/<int:oid>/status")
    @staff_only
    def staff_status(oid):
        try: S.set_status(conn(), oid, request.form.get("new_status", ""), session["staff"], request.form.get("note") or None)
        except S.TransitionError as e: flash(str(e))
        return redirect(request.referrer or url_for("staff_home"))
    @app.post("/staff/orders/<int:oid>/assign")
    @staff_only
    def staff_assign(oid):
        S.assign(conn(), oid, request.form.get("who", ""), session["staff"]); return redirect(request.referrer or url_for("staff_home"))
    @app.get("/staff/picking")
    @staff_only
    def picking():
        totals, buckets = S.picking_list(conn()); return render_template("picking.html", totals=totals, buckets=buckets)

    @app.get("/pay/<token>")
    def pay(token):
        o = S.get_order_by_token(conn(), token); prov = payments.get_provider()
        if not o or token not in session.get("verified", []): abort(404)
        if not prov or o["status"] != "awaiting_payment": return redirect(url_for("tracking", token=token))
        base = os.environ.get("APP_BASE_URL", "").rstrip("/") or request.host_url.rstrip("/")
        try: return redirect(S.start_payment(conn(), o, prov, f"{base}/t/{token}?new=1", f"{base}/t/{token}"), 303)
        except payments.ProviderError: flash(T[cur_lang()]["err_payment"]); return redirect(url_for("tracking", token=token))

    @app.post("/webhooks/payment")  # CSRF-exempt: authenticated by provider signature instead
    def payment_webhook():
        prov = payments.get_provider()
        if not prov: abort(503)
        try: ev = prov.verify_and_parse(request.headers, request.get_data())
        except (payments.SignatureError, ValueError, KeyError): abort(400)
        if ev is None: return {"result": "ignored"}, 200
        return {"result": S.apply_payment_event(conn(), prov.name, ev)}, 200

    @app.route("/webhooks/whatsapp", methods=["GET", "POST"])
    def wa_webhook():
        if request.method == "GET":
            vt = os.environ.get("WHATSAPP_VERIFY_TOKEN")
            if vt and request.args.get("hub.mode") == "subscribe" and secrets.compare_digest(request.args.get("hub.verify_token", ""), vt):
                return request.args.get("hub.challenge", ""), 200
            abort(403)
        raw = request.get_data()
        if not os.environ.get("WHATSAPP_APP_SECRET"): abort(503)
        if not whatsapp.verify_signature(raw, request.headers.get("X-Hub-Signature-256"), os.environ["WHATSAPP_APP_SECRET"]): abort(403)
        try: msgs = whatsapp.parse_inbound(request.get_json(force=True))
        except Exception: abort(400)
        c = conn()
        for m in msgs:
            with db.tx(c):
                try: c.execute("INSERT INTO inbound_messages VALUES(?,?)", (m["id"], S.iso(S.now())))
                except Exception: continue  # duplicate delivery
                for r in bot.handle(c, m["from"], m["text"]):
                    outbox.enqueue(c, m["from"], "reply", r[1], None, {"buttons": r[2]} if r[0] == "buttons" else None)
        outbox.process(c, app.config["TEST_MODE"])
        return "", 200

    @app.get("/staff/admin")
    @admin_only
    def admin():
        c = conn()
        return render_template("admin.html", products=c.execute("SELECT * FROM products ORDER BY id").fetchall(), areas=c.execute("SELECT * FROM delivery_areas ORDER BY id").fetchall(),
                               points=c.execute("SELECT * FROM pickup_points ORDER BY id").fetchall(), slots=c.execute("SELECT * FROM time_slots ORDER BY id").fetchall(),
                               settings={r[0]: r[1] for r in c.execute("SELECT key,value FROM settings")})
    @app.post("/staff/admin")
    @admin_only
    def admin_post():
        f, c = request.form, conn(); act = f.get("action")
        def txt(k):
            v = (f.get(k) or "").strip()
            if not v: raise ValueError(k)
            return v
        def fils(k):
            v = round(float(f[k]) * 100)
            if v < 0: raise ValueError(k)
            return v
        def opt_int(k): return int(f[k]) if (f.get(k) or "").strip() else None
        try:
            with db.tx(c):
                if act == "product_add": c.execute("INSERT INTO products(name_en,name_ar,pkg_en,pkg_ar,price_fils,stock_on_hand) VALUES(?,?,?,?,?,?)", (txt("name_en"), txt("name_ar"), txt("pkg_en"), txt("pkg_ar"), fils("price"), int(f["stock"])))
                elif act == "product_update": c.execute("UPDATE products SET price_fils=?, stock_on_hand=?, active=? WHERE id=?", (fils("price"), int(f["stock"]), 1 if f.get("active") else 0, int(f["id"])))
                elif act == "area_add": c.execute("INSERT INTO delivery_areas(name,fee_fils,free_over_qty) VALUES(?,?,?)", (txt("name"), fils("fee"), opt_int("free_qty")))
                elif act == "area_update": c.execute("UPDATE delivery_areas SET fee_fils=?, free_over_qty=?, active=? WHERE id=?", (fils("fee"), opt_int("free_qty"), 1 if f.get("active") else 0, int(f["id"])))
                elif act == "slot_add": c.execute("INSERT INTO time_slots(label) VALUES(?)", (txt("label"),))
                elif act == "pickup_add": c.execute("INSERT INTO pickup_points(name,hours) VALUES(?,?)", (txt("name"), txt("hours")))
                elif act == "toggle" and f.get("kind") in ("time_slots", "pickup_points"): c.execute(f"UPDATE {f['kind']} SET active=1-active WHERE id=?", (int(f["id"]),))
                elif act == "setting" and f.get("key") in ("cod_enabled", "online_enabled", "discount_percent", "delay_minutes", "max_qty_per_line", "support_phone"):
                    c.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (f["key"], (f.get("value") or "").strip()))
                else: raise ValueError("action")
        except (ValueError, KeyError, sqlite3.IntegrityError): flash("Not saved: please check the values (stock cannot be lower than reserved packs).")
        else: flash("Saved")
        return redirect(url_for("admin"))

    @app.get("/staff/report")
    @staff_only
    def report():
        by_status, top, rev = S.report(conn()); return render_template("report.html", by_status=by_status, top=top, rev=rev)
    @app.get("/staff/handoffs")
    @staff_only
    def handoffs():
        return render_template("handoffs.html", rows=conn().execute("SELECT * FROM handoffs WHERE resolved=0 ORDER BY id").fetchall())
    @app.post("/staff/handoffs/<int:hid>/resolve")
    @staff_only
    def resolve_handoff(hid):
        c = conn()
        with db.tx(c): c.execute("UPDATE handoffs SET resolved=1 WHERE id=?", (hid,))
        return redirect(url_for("handoffs"))

    # ---- CLI ----
    @app.cli.command("create-staff")
    @click.argument("username")
    @click.option("--role", default="staff")
    @click.password_option()
    def create_staff(username, role, password):
        if len(password) < 10: raise click.ClickException("Password must be at least 10 characters")
        c = conn()
        with db.tx(c): c.execute("INSERT INTO staff(username,pw_hash,role) VALUES(?,?,?)", (username, generate_password_hash(password), role))
        click.echo("created")
    @app.cli.command("set-setting")
    @click.argument("key")
    @click.argument("value")
    def set_setting(key, value):
        c = conn()
        with db.tx(c): c.execute("INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    @app.cli.command("add-product")
    @click.argument("name_en")
    @click.argument("name_ar")
    @click.argument("pkg_en")
    @click.argument("pkg_ar")
    @click.argument("price_aed", type=float)
    @click.argument("stock", type=int)
    def add_product(name_en, name_ar, pkg_en, pkg_ar, price_aed, stock):
        c = conn()
        with db.tx(c): c.execute("INSERT INTO products(name_en,name_ar,pkg_en,pkg_ar,price_fils,stock_on_hand) VALUES(?,?,?,?,?,?)",
                                 (name_en, name_ar, pkg_en, pkg_ar, round(price_aed * 100), stock))
    @app.cli.command("set-stock")
    @click.argument("product_id", type=int)
    @click.argument("on_hand", type=int)
    def set_stock(product_id, on_hand):
        c = conn()
        with db.tx(c): c.execute("UPDATE products SET stock_on_hand=? WHERE id=?", (on_hand, product_id))
    @app.cli.command("seed-sample")
    def seed_sample():
        """LOCAL TESTING ONLY: placeholder catalogue. Prices/areas/locations are NOT real business data."""
        c = conn()
        with db.tx(c):
            c.execute("INSERT INTO products(name_en,name_ar,pkg_en,pkg_ar,price_fils,stock_on_hand) VALUES('SAMPLE Eggs','بيض (تجريبي)','Carton of 30','كرتون ٣٠',1500,40)")
            c.execute("INSERT INTO delivery_areas(name,fee_fils,free_over_fils) VALUES('SAMPLE Area A / منطقة أ',1000,10000)")
            c.execute("INSERT INTO pickup_points(name,hours) VALUES('SAMPLE Pickup Point / نقطة تجريبية','09:00-17:00')")
            c.execute("INSERT INTO time_slots(label) VALUES('09:00-12:00'),('16:00-19:00')")
        click.echo("sample data added (replace with real data before launch)")
    @app.cli.command("add-area")
    @click.argument("name")
    @click.argument("fee_aed", type=float)
    @click.option("--free-over", type=float, default=None, help="free delivery when subtotal (AED) reaches this")
    @click.option("--free-over-qty", type=int, default=None, help="free delivery when total packs reach this number")
    def add_area(name, fee_aed, free_over, free_over_qty):
        c = conn()
        with db.tx(c): c.execute("INSERT INTO delivery_areas(name,fee_fils,free_over_fils,free_over_qty) VALUES(?,?,?,?)",
                                 (name, round(fee_aed * 100), None if free_over is None else round(free_over * 100), free_over_qty))
    @app.cli.command("add-pickup")
    @click.argument("name")
    @click.argument("hours")
    def add_pickup(name, hours):
        c = conn()
        with db.tx(c): c.execute("INSERT INTO pickup_points(name,hours) VALUES(?,?)", (name, hours))
    @app.cli.command("add-slot")
    @click.argument("label")
    def add_slot(label):
        c = conn()
        with db.tx(c): c.execute("INSERT INTO time_slots(label) VALUES(?)", (label,))
    @app.cli.command("send-outbox")
    def send_outbox():
        """Send pending notifications (run every minute via cron/systemd timer). Sends nothing in TEST_MODE."""
        click.echo(f"processed, sent={outbox.process(conn(), app.config['TEST_MODE'])}")
    return app
