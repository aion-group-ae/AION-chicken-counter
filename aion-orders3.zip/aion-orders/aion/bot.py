"""Deterministic WhatsApp menu bot (works with no LLM). Prices/stock/status always come from the database."""
import os, re
from .i18n import T
from .services import normalize_phone, now, iso, setting

AR = re.compile(r"[\u0600-\u06FF]")
def _kw(text, words): return any(w in text for w in words)

def handle(conn, phone, text):
    """Return list of replies: ('text', str) | ('buttons', str, [(id,title)])."""
    text = (text or "").strip(); low = text.lower()
    lang = "ar" if AR.search(text) else "en"
    t = T[lang]; base = os.environ.get("APP_BASE_URL", "").rstrip("/")
    s = conn.execute("SELECT * FROM wa_sessions WHERE phone=?", (phone,)).fetchone()
    state, misses = (s["state"], s["misses"]) if s else ("menu", 0)
    def save(st, m=0):
        conn.execute("INSERT INTO wa_sessions(phone,state,misses,updated_at) VALUES(?,?,?,?) ON CONFLICT(phone) DO UPDATE SET state=excluded.state,misses=excluded.misses,updated_at=excluded.updated_at",
                     (phone, st, m, iso(now())))
    def handoff(reason):
        conn.execute("INSERT INTO handoffs(phone,text,reason,created_at) VALUES(?,?,?,?)", (phone, text[:500], reason, iso(now()))); save("menu")
        return [("text", "سيتواصل معك أحد موظفينا قريباً.\nA team member will contact you shortly.")]
    menu = [("buttons", f"{t['brand']}\n1) {t['new_order']}\n2) {t['track']}\n3) {t['products']}\n4) {t['support']}",
             [("menu_order", t["new_order"]), ("menu_track", t["track"]), ("menu_products", t["products"])])]

    if state == "track" and not _kw(low, ["menu", "قائمة"]):
        o = conn.execute("SELECT * FROM orders WHERE order_no=? AND phone=?", (text.upper().replace(" ", ""), phone)).fetchone()  # sender number is WhatsApp-authenticated
        save("menu")
        if not o: return [("text", t["err_verify"])] + menu
        st = t["ready_" + o["method"]] if o["status"] == "ready" else t["st_" + o["status"]]
        link = f"\n{base}/t/{o['token']}" if base else ""
        return [("text", f"{o['order_no']}\n{t['status']}: {st}\n{t['pay_status']}: {t['ps_' + o['payment_status']]}\n{t['total']}: {o['total_fils']/100:.2f} {t['aed']}{link}")]
    if low in ("1", "menu_order") or _kw(low, ["order", "طلب"]) and not _kw(low, ["track", "تتبع", "status"]):
        save("menu"); return [("text", f"{t['new_order']}: {base}/order?lang={lang}" if base else t["err_payment"])]
    if low in ("2", "menu_track") or _kw(low, ["track", "تتبع", "status"]):
        save("track"); return [("text", t["order_no"] + "؟ / ?")]
    if low in ("3", "menu_products") or _kw(low, ["price", "product", "سعر", "اسعار", "أسعار", "منتج"]):
        save("menu"); rows = conn.execute("SELECT *,stock_on_hand-stock_reserved AS avail FROM products WHERE active=1").fetchall()
        return [("text", "\n".join(f"{p['name_'+lang]} — {p['pkg_'+lang]}: {p['price_fils']/100:.2f} {t['aed']} ({t['available'] if p['avail']>0 else t['out']})" for p in rows) or t["none"])]
    if low == "4" or _kw(low, ["support", "complaint", "human", "دعم", "شكوى", "موظف"]): return handoff("requested")
    if misses >= 1: return handoff("not understood")
    save("menu", misses + 1); return menu
