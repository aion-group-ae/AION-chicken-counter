import sqlite3, os, contextlib
MIG_DIR = os.path.join(os.path.dirname(__file__), "migrations")

def connect(path):
    c = sqlite3.connect(path, isolation_level=None, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    if path != ":memory:":
        c.execute("PRAGMA journal_mode=WAL")
    return c

@contextlib.contextmanager
def tx(conn):
    """Write transaction; takes the write lock up front so stock checks cannot race."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK"); raise
    else:
        conn.execute("COMMIT")

def migrate(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations(name TEXT PRIMARY KEY)")
    done = {r[0] for r in conn.execute("SELECT name FROM schema_migrations")}
    for f in sorted(os.listdir(MIG_DIR)):
        if f.endswith(".sql") and f not in done:
            with tx(conn):
                with open(os.path.join(MIG_DIR, f), encoding="utf-8") as fh:
                    sql = fh.read()
                for stmt in sql.split(";\n"):
                    if stmt.strip():
                        conn.execute(stmt)
                conn.execute("INSERT INTO schema_migrations VALUES(?)", (f,))
    defaults = {"cod_enabled": "1", "discount_percent": "0", "delay_minutes": "120", "max_qty_per_line": "50", "support_phone": ""}
    with tx(conn):
        for k, v in defaults.items():
            conn.execute("INSERT OR IGNORE INTO settings VALUES(?,?)", (k, v))
