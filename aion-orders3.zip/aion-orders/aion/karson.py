"""Karson integration — NOT IMPLEMENTED on purpose.
Web searches did not identify a product/provider called "Karson" with an official API (only an unrelated PHP M-Pesa SDK
by a developer of that name). To implement this adapter we need: the exact provider name and website, a link to its official
API/webhook documentation, what it should do (messages? payments? calls? CRM sync?), and sandbox credentials."""
class NotConfigured(Exception): pass
class KarsonAdapter:
    def send_message(self, phone, body): raise NotConfigured("Karson provider not identified")
    def handle_webhook(self, headers, raw): raise NotConfigured("Karson provider not identified")
def get_adapter(): raise NotConfigured("Karson provider not identified; see aion/karson.py")
