CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE products(id INTEGER PRIMARY KEY, name_en TEXT NOT NULL, name_ar TEXT NOT NULL,
  pkg_en TEXT NOT NULL, pkg_ar TEXT NOT NULL, price_fils INTEGER NOT NULL CHECK(price_fils>=0),
  stock_on_hand INTEGER NOT NULL DEFAULT 0, stock_reserved INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  CHECK(stock_on_hand>=0), CHECK(stock_reserved>=0), CHECK(stock_reserved<=stock_on_hand));
CREATE TABLE delivery_areas(id INTEGER PRIMARY KEY, name TEXT NOT NULL, fee_fils INTEGER NOT NULL DEFAULT 0,
  free_over_fils INTEGER, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE pickup_points(id INTEGER PRIMARY KEY, name TEXT NOT NULL, hours TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE time_slots(id INTEGER PRIMARY KEY, label TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE staff(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pw_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'staff' CHECK(role IN ('staff','admin')), active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE orders(id INTEGER PRIMARY KEY, order_no TEXT UNIQUE NOT NULL, token TEXT UNIQUE NOT NULL,
  idem_key TEXT UNIQUE, customer_name TEXT NOT NULL, phone TEXT NOT NULL,
  method TEXT NOT NULL CHECK(method IN ('delivery','pickup')), place_label TEXT NOT NULL, address TEXT,
  fulfil_date TEXT NOT NULL, slot_label TEXT NOT NULL,
  subtotal_fils INTEGER NOT NULL, delivery_fee_fils INTEGER NOT NULL, discount_fils INTEGER NOT NULL, total_fils INTEGER NOT NULL,
  status TEXT NOT NULL, payment_method TEXT NOT NULL,
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK(payment_status IN ('pending','paid','failed','cancelled','refunded')),
  assigned_to TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_phone ON orders(phone);
CREATE TABLE order_items(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id), qty INTEGER NOT NULL CHECK(qty>0), unit_price_fils INTEGER NOT NULL);
CREATE TABLE audit_log(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
  at TEXT NOT NULL, actor TEXT NOT NULL, old_status TEXT, new_status TEXT NOT NULL, note TEXT);
