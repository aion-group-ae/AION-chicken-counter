CREATE TABLE payments(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), provider TEXT NOT NULL,
  provider_ref TEXT, amount_fils INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'AED',
  status TEXT NOT NULL CHECK(status IN ('pending','paid','failed','cancelled','refunded')), note TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE TABLE webhook_events(provider TEXT NOT NULL, event_id TEXT NOT NULL, received_at TEXT NOT NULL, PRIMARY KEY(provider,event_id));
CREATE TABLE outbox(id INTEGER PRIMARY KEY, order_id INTEGER, phone TEXT NOT NULL, kind TEXT NOT NULL, body TEXT NOT NULL, payload TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','sent','failed','test')), attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT, created_at TEXT NOT NULL, next_try_at TEXT NOT NULL);
CREATE INDEX idx_outbox_status ON outbox(status,next_try_at);
CREATE TABLE inbound_messages(id TEXT PRIMARY KEY, received_at TEXT NOT NULL);
CREATE TABLE wa_sessions(phone TEXT PRIMARY KEY, state TEXT NOT NULL DEFAULT 'menu', misses INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
CREATE TABLE handoffs(id INTEGER PRIMARY KEY, phone TEXT NOT NULL, text TEXT, reason TEXT NOT NULL, created_at TEXT NOT NULL, resolved INTEGER NOT NULL DEFAULT 0);
