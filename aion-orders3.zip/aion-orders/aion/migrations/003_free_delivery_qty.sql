ALTER TABLE delivery_areas ADD COLUMN free_over_qty INTEGER;
