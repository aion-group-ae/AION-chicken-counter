"""Durable message queue: nothing is sent inline; failures retry with backoff; TEST_MODE never sends."""
import json
from datetime import timedelta
from . import whatsapp
from .db import tx
from datetime import datetime, timezone

def now(): return datetime.now(timezone.utc).replace(microsecond=0)
def iso(dt): return dt.isoformat(timespec="seconds")
def setting(conn, key, default=""):
    r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else default

MAX_ATTEMPTS = 5

def enqueue(conn, phone, kind, body, order_id=None, payload=None):
    t = iso(now())
    conn.execute("INSERT INTO outbox(order_id,phone,kind,body,payload,created_at,next_try_at) VALUES(?,?,?,?,?,?,?)",
                 (order_id, phone, kind, body, json.dumps(payload) if payload else None, t, t))

def process(conn, test_mode=True, limit=20):
    rows = conn.execute("SELECT * FROM outbox WHERE status='pending' AND next_try_at<=? ORDER BY id LIMIT ?", (iso(now()), limit)).fetchall()
    sent = 0
    for r in rows:
        if test_mode:
            with tx(conn): conn.execute("UPDATE outbox SET status='test' WHERE id=?", (r["id"],))
            continue
        err = None
        try:
            if not whatsapp.configured(): raise whatsapp.WAError("not configured")
            p = json.loads(r["payload"]) if r["payload"] else {}
            tpl = setting(conn, "wa_template_" + r["kind"])
            if p.get("buttons"): whatsapp.send_buttons(r["phone"], r["body"], p["buttons"])
            elif tpl and p.get("order_no"): whatsapp.send_template(r["phone"], tpl, setting(conn, "wa_template_lang", "ar"), [p["order_no"]])
            else: whatsapp.send_text(r["phone"], r["body"])  # free text only works inside WhatsApp's 24h customer-service window
        except whatsapp.WAError as e: err = str(e)
        with tx(conn):
            if err is None: conn.execute("UPDATE outbox SET status='sent', attempts=attempts+1 WHERE id=?", (r["id"],)); sent += 1
            else:
                a = r["attempts"] + 1
                conn.execute("UPDATE outbox SET status=?, attempts=?, last_error=?, next_try_at=? WHERE id=?",
                             ("failed" if a >= MAX_ATTEMPTS else "pending", a, err, iso(now() + timedelta(minutes=2 ** a)), r["id"]))
    return sent
