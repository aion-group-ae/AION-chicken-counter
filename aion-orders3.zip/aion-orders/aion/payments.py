"""Payment-provider adapter. Only Stripe Checkout (hosted page) is implemented; no card data ever touches this app."""
import hmac, hashlib, json, os, time, urllib.request, urllib.parse, urllib.error

class ProviderError(Exception): pass
class SignatureError(Exception): pass

class Provider:
    name = "base"
    def create_checkout(self, order_no, total_fils, currency, success_url, cancel_url):  # -> (url, provider_ref)
        raise NotImplementedError
    def verify_and_parse(self, headers, raw):  # -> dict(kind,event_id,order_no,amount,currency,ref) | None ; raises SignatureError
        raise NotImplementedError

class StripeProvider(Provider):
    name = "stripe"
    def __init__(self, secret_key, webhook_secret, tolerance=300):
        self.key, self.wh, self.tol = secret_key, webhook_secret, tolerance

    def create_checkout(self, order_no, total_fils, currency, success_url, cancel_url):
        d = {"mode": "payment", "success_url": success_url, "cancel_url": cancel_url, "client_reference_id": order_no,
             "metadata[order_no]": order_no, "line_items[0][quantity]": "1",
             "line_items[0][price_data][currency]": currency.lower(), "line_items[0][price_data][unit_amount]": str(total_fils),
             "line_items[0][price_data][product_data][name]": f"AION order {order_no}"}
        req = urllib.request.Request("https://api.stripe.com/v1/checkout/sessions", urllib.parse.urlencode(d).encode(),
                                     {"Authorization": f"Bearer {self.key}", "Idempotency-Key": f"{order_no}-{int(time.time()//600)}"})
        try:
            with urllib.request.urlopen(req, timeout=15) as r: j = json.load(r)
        except urllib.error.HTTPError as e: raise ProviderError(f"provider HTTP {e.code}") from None
        except Exception: raise ProviderError("provider unreachable") from None
        if not j.get("url"): raise ProviderError("no checkout url")
        return j["url"], j["id"]

    def verify_and_parse(self, headers, raw, now=None):
        parts = dict(p.split("=", 1) for p in (headers.get("Stripe-Signature") or "").split(",") if "=" in p)
        t, sigs = parts.get("t"), [v for k, v in (x.split("=", 1) for x in (headers.get("Stripe-Signature") or "").split(",") if "=" in x) if k == "v1"]
        if not t or not sigs or not t.isdigit(): raise SignatureError("bad header")
        if abs((now or time.time()) - int(t)) > self.tol: raise SignatureError("stale")
        exp = hmac.new(self.wh.encode(), t.encode() + b"." + raw, hashlib.sha256).hexdigest()
        if not any(hmac.compare_digest(exp, s) for s in sigs): raise SignatureError("bad signature")
        ev = json.loads(raw); typ = ev.get("type"); o = (ev.get("data") or {}).get("object") or {}
        kind = {"checkout.session.async_payment_succeeded": "paid", "checkout.session.async_payment_failed": "failed",
                "checkout.session.expired": "expired"}.get(typ)
        if typ == "checkout.session.completed" and o.get("payment_status") == "paid": kind = "paid"
        if not kind: return None
        return {"kind": kind, "event_id": ev["id"], "order_no": o.get("client_reference_id"), "amount": o.get("amount_total"),
                "currency": (o.get("currency") or "").upper(), "ref": o.get("id")}

def get_provider():
    if os.environ.get("PAYMENT_PROVIDER") == "stripe" and os.environ.get("PAYMENT_SECRET_KEY") and os.environ.get("PAYMENT_WEBHOOK_SECRET"):
        return StripeProvider(os.environ["PAYMENT_SECRET_KEY"], os.environ["PAYMENT_WEBHOOK_SECRET"])
    return None
def configured(): return get_provider() is not None
