"""Official WhatsApp Business Cloud API only (no unofficial automation)."""
import hmac, hashlib, json, os, urllib.request, urllib.error

class WAError(Exception): pass

def configured(): return bool(os.environ.get("WHATSAPP_PHONE_NUMBER_ID") and os.environ.get("WHATSAPP_ACCESS_TOKEN"))
def verify_signature(raw, header, app_secret):
    if not app_secret or not header or not header.startswith("sha256="): return False
    return hmac.compare_digest(hmac.new(app_secret.encode(), raw, hashlib.sha256).hexdigest(), header[7:])

def _post(payload):
    url = f"https://graph.facebook.com/{os.environ.get('WHATSAPP_API_VERSION', 'v21.0')}/{os.environ['WHATSAPP_PHONE_NUMBER_ID']}/messages"
    req = urllib.request.Request(url, json.dumps(payload).encode(), {"Authorization": "Bearer " + os.environ["WHATSAPP_ACCESS_TOKEN"], "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r: return json.load(r)
    except urllib.error.HTTPError as e: raise WAError(f"HTTP {e.code}") from None  # never include token/body in errors
    except Exception: raise WAError("unreachable") from None

def send_text(to, body): return _post({"messaging_product": "whatsapp", "to": to.lstrip("+"), "type": "text", "text": {"body": body}})
def send_buttons(to, body, buttons):  # up to 3 (id, title<=20 chars)
    return _post({"messaging_product": "whatsapp", "to": to.lstrip("+"), "type": "interactive", "interactive": {"type": "button",
        "body": {"text": body}, "action": {"buttons": [{"type": "reply", "reply": {"id": i, "title": t[:20]}} for i, t in buttons[:3]]}}})
def send_template(to, name, lang, params):
    return _post({"messaging_product": "whatsapp", "to": to.lstrip("+"), "type": "template", "template": {"name": name, "language": {"code": lang},
        "components": [{"type": "body", "parameters": [{"type": "text", "text": p} for p in params]}]}})

def parse_inbound(payload):
    out = []
    for e in payload.get("entry", []):
        for ch in e.get("changes", []):
            for m in (ch.get("value") or {}).get("messages", []) or []:
                text = (m.get("text") or {}).get("body") or ((m.get("interactive") or {}).get("button_reply") or {}).get("id") or ""
                out.append({"id": m["id"], "from": "+" + m["from"], "text": text})
    return out
