import hashlib, hmac, json, os, tempfile, time, unittest
from unittest import mock
from aion import db, services as S, payments, whatsapp, outbox, karson
from tests.test_core import Base, form, TestHTTP
from aion.app import create_app

ENV = {"PAYMENT_PROVIDER": "stripe", "PAYMENT_SECRET_KEY": "sk_test_x", "PAYMENT_WEBHOOK_SECRET": "whsec_test",
       "WHATSAPP_APP_SECRET": "appsecret", "WHATSAPP_VERIFY_TOKEN": "vtok", "APP_BASE_URL": "https://shop.example"}

def stripe_event(order_no, amount, kind="checkout.session.completed", eid="evt_1", currency="aed", paid="paid"):
    return json.dumps({"id": eid, "type": kind, "data": {"object": {"id": "cs_1", "client_reference_id": order_no, "amount_total": amount,
                                                                    "currency": currency, "payment_status": paid}}}).encode()
def stripe_sig(raw, secret="whsec_test", t=None):
    t = str(t or int(time.time())); return {"Stripe-Signature": f"t={t},v1=" + hmac.new(secret.encode(), t.encode() + b"." + raw, hashlib.sha256).hexdigest()}
def wa_sig(raw, secret="appsecret"): return {"X-Hub-Signature-256": "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()}
def wa_msg(mid, frm, text): return json.dumps({"entry": [{"changes": [{"value": {"messages": [{"id": mid, "from": frm, "text": {"body": text}}]}}]}]}).encode()

class Env(Base):
    def setUp(self):
        super().setUp(); p = mock.patch.dict(os.environ, ENV); p.start(); self.addCleanup(p.stop)

class TestPayments(Env):
    def online(self, qty=2): return S.create_order(self.c, form(qty, payment_method="online"))
    def hook(self, cl, raw, headers=None): return cl.post("/webhooks/payment", data=raw, headers=headers or stripe_sig(raw))
    def row(self, o): return self.c.execute("SELECT * FROM orders WHERE id=?", (o["id"],)).fetchone()

    def test_online_unavailable_without_provider(self):
        with mock.patch.dict(os.environ, {"PAYMENT_PROVIDER": ""}):
            with self.assertRaises(S.OrderError) as cm: S.create_order(self.c, form(payment_method="online"))
            self.assertEqual(cm.exception.code, "payment")
    def test_signature_checks(self):
        p = payments.get_provider(); raw = stripe_event("X", 100)
        self.assertEqual(p.verify_and_parse(stripe_sig(raw), raw)["kind"], "paid")
        for h, body in ((stripe_sig(raw, "wrong"), raw), (stripe_sig(raw), raw + b" "), (stripe_sig(raw, t=int(time.time()) - 3600), raw), ({}, raw)):
            with self.assertRaises(payments.SignatureError): p.verify_and_parse(h, body)
    def test_online_order_waits_for_verified_webhook(self):
        o = self.online(); self.assertEqual((o["status"], o["payment_status"]), ("awaiting_payment", "pending"))
        cl = self.app.test_client(); raw = stripe_event(o["order_no"], o["total_fils"])
        self.assertEqual(self.hook(cl, raw, {"Stripe-Signature": "t=1,v1=bad"}).status_code, 400)   # forged
        self.assertEqual(self.row(o)["status"], "awaiting_payment")
        cl.get(f"/t/{o['token']}?new=1")                                                            # customer 'returns from checkout'
        self.assertEqual(self.row(o)["payment_status"], "pending")
        self.assertEqual(self.hook(cl, raw).get_json()["result"], "paid")
        r = self.row(o); self.assertEqual((r["status"], r["payment_status"]), ("paid", "paid"))
        self.assertEqual(self.hook(cl, raw).get_json()["result"], "duplicate")                      # replay
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM audit_log WHERE order_id=? AND new_status='paid'", (o["id"],)).fetchone()[0], 1)
    def test_amount_mismatch_not_paid(self):
        o = self.online(); cl = self.app.test_client()
        self.assertEqual(self.hook(cl, stripe_event(o["order_no"], 100)).get_json()["result"], "amount_mismatch")
        self.assertEqual(self.row(o)["status"], "awaiting_payment")
        self.assertEqual(self.hook(cl, stripe_event(o["order_no"], o["total_fils"], eid="e2", currency="usd")).get_json()["result"], "amount_mismatch")
    def test_failed_payment_keeps_order_open(self):
        o = self.online(); cl = self.app.test_client()
        self.hook(cl, stripe_event(o["order_no"], o["total_fils"], "checkout.session.async_payment_failed", "e3", paid="unpaid"))
        r = self.row(o); self.assertEqual((r["status"], r["payment_status"]), ("awaiting_payment", "failed"))
    def test_unpaid_completed_event_ignored(self):
        o = self.online(); raw = stripe_event(o["order_no"], o["total_fils"], paid="unpaid")
        self.assertEqual(self.hook(self.app.test_client(), raw).get_json()["result"], "ignored"); self.assertEqual(self.row(o)["payment_status"], "pending")
    def test_pay_route_creates_payment_row_and_redirects(self):
        o = self.online(); cl = self.app.test_client()
        with cl.session_transaction() as s: s["verified"] = [o["token"]]
        with mock.patch.object(payments.StripeProvider, "create_checkout", return_value=("https://checkout.stripe.com/c/x", "cs_1")):
            r = cl.get(f"/pay/{o['token']}")
        self.assertEqual((r.status_code, r.headers["Location"]), (303, "https://checkout.stripe.com/c/x"))
        self.assertEqual(self.c.execute("SELECT status,amount_fils FROM payments").fetchone()[:], ("pending", o["total_fils"]))
    def test_pay_route_requires_verification(self):
        o = self.online(); self.assertEqual(self.app.test_client().get(f"/pay/{o['token']}").status_code, 404)

class TestWhatsApp(Env):
    def post(self, cl, raw, h=None): return cl.post("/webhooks/whatsapp", data=raw, headers=h or wa_sig(raw))
    def replies(self): return [r["body"] for r in self.c.execute("SELECT body FROM outbox WHERE kind='reply' ORDER BY id")]
    def test_verification_handshake(self):
        cl = self.app.test_client()
        self.assertEqual(cl.get("/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=vtok&hub.challenge=123").get_data(as_text=True), "123")
        self.assertEqual(cl.get("/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=no&hub.challenge=1").status_code, 403)
    def test_signature_required(self):
        cl = self.app.test_client(); raw = wa_msg("m1", "971501234567", "hi")
        self.assertEqual(self.post(cl, raw, {"X-Hub-Signature-256": "sha256=00"}).status_code, 403)
        with mock.patch.dict(os.environ, {"WHATSAPP_APP_SECRET": ""}): self.assertEqual(self.post(cl, raw).status_code, 503)
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM outbox").fetchone()[0], 0)
    def test_test_mode_never_sends(self):
        cl = self.app.test_client()
        with mock.patch("urllib.request.urlopen", side_effect=AssertionError("network call in test mode")):
            self.assertEqual(self.post(cl, wa_msg("m1", "971501234567", "hi")).status_code, 200)
        self.assertEqual(self.c.execute("SELECT status FROM outbox").fetchone()[0], "test")
    def test_duplicate_delivery_ignored(self):
        cl = self.app.test_client(); raw = wa_msg("m1", "971501234567", "3"); self.post(cl, raw); self.post(cl, raw)
        self.assertEqual(len(self.replies()), 1)
    def test_prices_come_from_database_in_arabic(self):
        self.post(self.app.test_client(), wa_msg("m1", "971501234567", "أسعار")); r = self.replies()[0]
        self.assertIn("15.00", r); self.assertIn("بيض", r)
    def test_track_only_own_order(self):
        o = S.create_order(self.c, form(1)); cl = self.app.test_client()
        self.post(cl, wa_msg("a", "971501234567", "track")); self.post(cl, wa_msg("b", "971501234567", o["order_no"]))
        self.assertIn(o["order_no"], self.replies()[-1]); self.assertIn("Payment method confirmed", self.replies()[-1])
        self.post(cl, wa_msg("c", "971509999999", "track")); self.post(cl, wa_msg("d", "971509999999", o["order_no"]))
        self.assertNotIn(o["order_no"], self.replies()[-2])
    def test_handoff_on_support_and_confusion(self):
        cl = self.app.test_client(); self.post(cl, wa_msg("a", "971501234567", "I want to complain, human please"))
        self.post(cl, wa_msg("b", "971502222222", "asdf")); self.post(cl, wa_msg("c", "971502222222", "qwer"))
        self.assertEqual(self.c.execute("SELECT COUNT(*) FROM handoffs").fetchone()[0], 2)

class TestOutbox(Env):
    def test_status_changes_enqueue_notifications(self):
        o = S.create_order(self.c, form(1)); S.set_status(self.c, o["id"], "queued", "sam")
        for s in ("picking", "quality_check", "packing", "ready", "handed_over"): S.set_status(self.c, o["id"], s, "sam")
        kinds = [r[0] for r in self.c.execute("SELECT kind FROM outbox ORDER BY id")]
        self.assertEqual(kinds, ["order_paid", "order_ready", "order_handed_over"]); self.assertIn("https://shop.example/t/", self.c.execute("SELECT body FROM outbox").fetchone()[0])
    def test_retry_then_fail_and_never_leaks_token(self):
        outbox.enqueue(self.c, "+971501234567", "reply", "hi"); calls = []
        def boom(*a, **k): calls.append(1); raise whatsapp.WAError("HTTP 500")
        with mock.patch.dict(os.environ, {"WHATSAPP_PHONE_NUMBER_ID": "1", "WHATSAPP_ACCESS_TOKEN": "SECRET_TOKEN"}), mock.patch.object(whatsapp, "send_text", boom):
            for _ in range(5):
                with db.tx(self.c): self.c.execute("UPDATE outbox SET next_try_at='2000-01-01T00:00:00+00:00'")
                outbox.process(self.c, test_mode=False)
        r = self.c.execute("SELECT * FROM outbox").fetchone(); self.assertEqual((r["status"], r["attempts"], len(calls)), ("failed", 5, 5)); self.assertNotIn("SECRET_TOKEN", r["last_error"])
    def test_successful_send_marked_sent(self):
        outbox.enqueue(self.c, "+971501234567", "reply", "hi")
        with mock.patch.dict(os.environ, {"WHATSAPP_PHONE_NUMBER_ID": "1", "WHATSAPP_ACCESS_TOKEN": "t"}), mock.patch.object(whatsapp, "send_text", return_value={}) as m:
            self.assertEqual(outbox.process(self.c, test_mode=False), 1)
        m.assert_called_once_with("+971501234567", "hi"); self.assertEqual(self.c.execute("SELECT status FROM outbox").fetchone()[0], "sent")

class TestKarsonAndStaff(Base):
    place = TestHTTP.place; post = TestHTTP.post; csrf = TestHTTP.csrf
    def test_karson_is_explicitly_unconfigured(self):
        with self.assertRaises(karson.NotConfigured): karson.get_adapter()
    def test_report_and_handoff_pages_need_login(self):
        cl = self.app.test_client()
        for p in ("/staff/report", "/staff/handoffs"): self.assertEqual(cl.get(p).status_code, 302)
        self.post(cl, "/staff/login", {"username": "sam", "password": "correct-horse-1"}, "/staff/login")
        self.place(self.app.test_client())
        for p in ("/staff/report", "/staff/handoffs"): self.assertEqual(cl.get(p).status_code, 200)
        self.assertIn("40.00", cl.get("/staff/report").get_data(as_text=True))

class TestAdminSetup(Base):
    def login(self, user, pw):
        cl = self.app.test_client(); h = cl.get("/staff/login").get_data(as_text=True)
        import re; tok = re.search(r'name="csrf" value="([^"]+)"', h).group(1); cl.post("/staff/login", data={"csrf": tok, "username": user, "password": pw}); return cl
    def tok(self, cl):
        import re; return re.search(r'name="csrf" value="([^"]+)"', cl.get("/staff/admin").get_data(as_text=True)).group(1)
    def test_empty_catalogue_shows_clear_message_not_form(self):
        with db.tx(self.c): self.c.execute("DELETE FROM products")
        h = self.app.test_client().get("/order").get_data(as_text=True); self.assertIn("not available yet", h); self.assertNotIn("<form", h)
    def test_admin_can_set_up_catalogue_then_customers_can_order(self):
        from werkzeug.security import generate_password_hash
        with db.tx(self.c):
            for t in ("order_items", "products", "delivery_areas", "time_slots"): self.c.execute(f"DELETE FROM {t}")
            self.c.execute("INSERT INTO staff(username,pw_hash,role) VALUES('boss',?,'admin')", (generate_password_hash("admin-pass-123"),))
        self.assertIn("not available yet", self.app.test_client().get("/order").get_data(as_text=True))
        cl = self.login("boss", "admin-pass-123"); t = self.tok(cl)
        for d in ({"action": "product_add", "name_en": "Eggs", "name_ar": "بيض", "pkg_en": "Pack of 15 eggs", "pkg_ar": "عبوة ١٥ بيضة", "price": "30", "stock": "20"},
                  {"action": "area_add", "name": "Abu Dhabi", "fee": "5", "free_qty": "7"}, {"action": "slot_add", "label": "09:00-12:00"}):
            cl.post("/staff/admin", data={**d, "csrf": t})
        h = self.app.test_client().get("/order").get_data(as_text=True); self.assertIn("Pack of 15 eggs", h); self.assertIn("30.00", h); self.assertIn("free delivery from 7 packs", h)
        q = S.build_quote(self.c, form(6)); self.assertEqual((q["fee"], q["total"]), (500, 18500)); self.assertEqual(S.build_quote(self.c, form(7))["fee"], 0)
    def test_staff_role_cannot_open_admin_and_bad_stock_rejected(self):
        self.assertEqual(self.login("sam", "correct-horse-1").get("/staff/admin").status_code, 403)
        from werkzeug.security import generate_password_hash
        with db.tx(self.c): self.c.execute("INSERT INTO staff(username,pw_hash,role) VALUES('boss',?,'admin')", (generate_password_hash("admin-pass-123"),))
        S.create_order(self.c, form(5)); cl = self.login("boss", "admin-pass-123")
        cl.post("/staff/admin", data={"action": "product_update", "id": "1", "price": "15", "stock": "2", "active": "1", "csrf": self.tok(cl)})
        self.assertEqual(self.c.execute("SELECT stock_on_hand FROM products").fetchone()[0], 10)
    def test_env_bootstrap_creates_first_admin_only(self):
        d = tempfile.TemporaryDirectory(); path = os.path.join(d.name, "b.db")
        with mock.patch.dict(os.environ, {"AION_ADMIN_USER": "owner", "AION_ADMIN_PASSWORD": "long-enough-pw"}):
            create_app({"DB_PATH": path}); create_app({"DB_PATH": path})
        c = db.connect(path); self.assertEqual([tuple(r) for r in c.execute("SELECT username,role FROM staff")], [("owner", "admin")]); c.close(); d.cleanup()

if __name__ == "__main__": unittest.main()
